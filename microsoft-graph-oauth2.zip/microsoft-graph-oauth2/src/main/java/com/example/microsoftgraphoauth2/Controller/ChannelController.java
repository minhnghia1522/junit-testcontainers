package com.example.microsoftgraphoauth2.Controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.microsoftgraphoauth2.Model.AuthenInfo;
import com.example.microsoftgraphoauth2.Model.Channel;
import com.example.microsoftgraphoauth2.Model.Message.Message;
import com.example.microsoftgraphoauth2.Service.RestClient;
import com.example.microsoftgraphoauth2.Util.ApplicationData;
import com.example.microsoftgraphoauth2.Util.Util;

@RestController
@RequestMapping("api")
public class ChannelController {
	@Autowired
	private RestClient<String> restClient;

	@Autowired
	private AuthenInfo authenInfo;
	
	@Autowired
	private ApplicationData applicationData;
	
	@Autowired
	private Util util;

	@GetMapping(value = "send-new-message")
	public String SendNewMessage() throws IOException {
		if (!util.isAccessTokenValid(authenInfo.getAccessToken())) {
			return "please sign in by url: /sign-in";
		}
		System.out.println("-----Send new message-----");
		Channel channel = new Channel(applicationData.getChannelID(),applicationData.getTeamID());
		Message message = channel.MessageRequiredInfo();
		restClient.setBodyRequest(new JSONObject(message).toString());
		restClient.getNewHeaders().set("Authorization", "Bearer " + authenInfo.getAccessToken());
		restClient.getHeaders().setContentType(MediaType.APPLICATION_JSON);
		String responseClient = new RestTemplate().postForObject(channel.getSendNewMessageUrl(), restClient.getRequest(),
				String.class);
		return responseClient;
	}

	@GetMapping(value = "reply-message")
	public String ReplyMessage() throws IOException {
		if (!util.isAccessTokenValid(authenInfo.getAccessToken())) {
			return "please sign in by url: /sign-in";
		}
		System.out.println("-----Reply message-----");
		Channel channel = new Channel(applicationData.getChannelID(),applicationData.getTeamID());
		Message message = channel.ReplyMessageRequiredInfo();
		restClient.setBodyRequest(new JSONObject(message).toString());
		restClient.getNewHeaders().set("Authorization", "Bearer " + authenInfo.getAccessToken());
		restClient.getHeaders().setContentType(MediaType.APPLICATION_JSON);
		String responseClient = new RestTemplate().postForObject(channel.getReplyMessageUrl(), restClient.getRequest(),
				String.class);
		return responseClient;
	}

	@GetMapping(value = "mention-so")
	public String MentionSO() throws IOException {
		if (!util.isAccessTokenValid(authenInfo.getAccessToken())) {
			return "please sign in by url: /sign-in";
		}
		System.out.println("-----Mention message-----");
		Channel channel = new Channel(applicationData.getChannelID(),applicationData.getTeamID());
		Message message = channel.MentionSORequiredInfo();
		restClient.setBodyRequest(new JSONObject(message).toString());
		restClient.getNewHeaders().set("Authorization", "Bearer " + authenInfo.getAccessToken());
		restClient.getHeaders().setContentType(MediaType.APPLICATION_JSON);
		String responseClient = new RestTemplate().postForObject(channel.getMentionSOUrl(), restClient.getRequest(),
				String.class);
		return responseClient;
	}
}
