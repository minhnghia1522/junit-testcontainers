package com.example.microsoftgraphoauth2.Controller;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.microsoftgraphoauth2.Model.AuthenInfo;
import com.example.microsoftgraphoauth2.Service.RestClient;
import com.example.microsoftgraphoauth2.Util.Contants;
import com.example.microsoftgraphoauth2.config.CustomUserDetails;

@RestController
public class SignInController {
	@Autowired
	private RestClient<String> restClient;

	@Autowired
	private AuthenInfo authenInfo;

	@GetMapping("api/token")
	public String GetAccessToken(@RequestParam String code) {
		authenInfo.setCode(code);
		RestTemplate restTemplate = new RestTemplate();
		MultiValueMap<String, String> authenMap = new LinkedMultiValueMap<String, String>();
		authenMap.add("client_id", authenInfo.getClientID());
		authenMap.add("scope", authenInfo.getScope());
		authenMap.add("code", authenInfo.getCode());
		authenMap.add("redirect_uri", authenInfo.getRedirectUri());
		authenMap.add("grant_type", "authorization_code");
		authenMap.add("client_secret", authenInfo.getClientSecret());
		restClient.getNewHeaders().setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		restClient.setBodyRequest(authenMap);
		String response = restTemplate.postForObject(
				Contants.SIGN_IN_MICROSOFT_DOMAIN + authenInfo.getTenantID() + Contants.FECTH_TOKEN,
				restClient.getRequestForm(), String.class);
		String access_token = new JSONObject(response).getString("access_token");
		authenInfo.setAccessToken(access_token);

//		CustomUserDetails userDetails = new CustomUserDetails();
//		UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userDetails, null,
//				userDetails.getAuthorities());
//		authentication.setDetails(new WebAuthenticationDetailsSource());
//		SecurityContextHolder.getContext().setAuthentication(authentication);

		System.out.print("access token: ");
		System.out.print(authenInfo.getAccessToken());
		return "sign in success";
	}
}
