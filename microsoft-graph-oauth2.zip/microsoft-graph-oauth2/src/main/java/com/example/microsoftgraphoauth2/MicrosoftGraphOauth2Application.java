package com.example.microsoftgraphoauth2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicrosoftGraphOauth2Application {

	public static void main(String[] args) {
		SpringApplication.run(MicrosoftGraphOauth2Application.class, args);
	}

}
