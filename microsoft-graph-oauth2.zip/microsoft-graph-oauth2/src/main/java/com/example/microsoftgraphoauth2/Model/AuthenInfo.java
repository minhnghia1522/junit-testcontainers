package com.example.microsoftgraphoauth2.Model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AuthenInfo {
	@Value("${azure.activedirectory.client-id}")
	private String clientID;
	@Value("${azure.activedirectory.client-secret}")
	private String clientSecret;
	@Value("${azure.activedirectory.tenant-id}")
	private String tenantID;
	@Value("${spring.cloud.azure.active-directory.scope}")
	private String scope;
	@Value("${azure.activedirectory.redirect-uri-template}")
	private String redirectUri;
//	@Value("${spring.cloud.azure.active-directory.credential.client-id}")
//	private String clientID;
//	@Value("${spring.cloud.azure.active-directory.credential.client-secret}")
//	private String clientSecret;
//	@Value("${spring.cloud.azure.active-directory.profile.tenant-id}")
//	private String tenantID;
//	@Value("${spring.cloud.azure.active-directory.scope}")
//	private String scope;
//	@Value("${spring.cloud.azure.active-directory.redirect-uri-template}")
//	private String redirectUri;
	private String accessToken;
	private String code;

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public String getTenantID() {
		return tenantID;
	}

	public void setTenantID(String tenantID) {
		this.tenantID = tenantID;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getRedirectUri() {
		return redirectUri;
	}

	public void setRedirectUri(String redirectUri) {
		this.redirectUri = redirectUri;
	}

}
