package com.example.microsoftgraphoauth2.Model;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.example.microsoftgraphoauth2.Model.Message.BodyMessage;
import com.example.microsoftgraphoauth2.Model.Message.MentionMessage;
import com.example.microsoftgraphoauth2.Model.Message.Mentioned;
import com.example.microsoftgraphoauth2.Model.Message.Message;
import com.example.microsoftgraphoauth2.Util.Contants;

@Component
public class Channel {
	@Value("${ChatDemo.channelID}")
	private String channelID;
	@Value("${ChatDemo.teamID}")
	private String teamID;
	private String messageID;


	public Channel(String channelID, String teamID) {
		this.channelID = channelID;
		this.teamID = teamID;
	}
	
	public Channel() {
	}

	public String getTeamID() {
		return teamID;
	}

	public void setTeamID(String teamID) {
		this.teamID = teamID;
	}

	public String getId() {
		return channelID;
	}

	public void setId(String channelID) {
		this.channelID = channelID;
	}

	public String getMessageID() {
		if (this.messageID == null || this.messageID.isBlank()) {
			Scanner sc = new Scanner(System.in);
			System.out.print("Message ID: ");
			this.messageID = sc.next();
		}
		return messageID;
	}

	public void setMessageID(String messageID) {
		this.messageID = messageID;
	}

	public String getSendNewMessageUrl() {
		return Contants.MICROSOFT_GRAPH_DOMAIN + "teams/" + this.teamID + "/channels/" + this.channelID + "/messages";
	}

	public String getReplyMessageUrl() {
		return Contants.MICROSOFT_GRAPH_DOMAIN + "teams/" + this.teamID + "/channels/" + this.channelID + "/messages/"
				+ this.getMessageID() + "/replies";
	}

	public String getMentionSOUrl() {
		return Contants.MICROSOFT_GRAPH_DOMAIN + "teams/" + this.teamID + "/channels/" + this.channelID + "/messages/"
				+ this.getMessageID() + "/replies";
	}

	public Message MessageRequiredInfo() {
		return this.CreateMessage();
	}

	public Message ReplyMessageRequiredInfo() {
		this.getMessageID();
		return this.CreateMessage();
	}

	public Message MentionSORequiredInfo() {
		this.getMessageID();
		Message message = this.CreateMessage();
		message.getBody().setContentType("html");

		User user = new User();
		user.getId();
		user.getDisplayName();
		user.setUserIdentityType("aadUser");

		Mentioned mentioned = new Mentioned();
		mentioned.setUser(user);
		
		MentionMessage mentionMessage = new MentionMessage();
		mentionMessage.setMentioned(mentioned);
		mentionMessage.setMentionText(user.getDisplayName());
		mentionMessage.setId("0");
		List<MentionMessage> mm = new ArrayList<>();
		mm.add(mentionMessage);
		message.setMentions(mm);
		message.getBody()
				.setContent(message.getBody().getContent() + " <at id=\"0\">" + user.getDisplayName() + "</at>");
		return message;
	}

	public Message CreateMessage() {
		Message message = new Message();
		BodyMessage bodymessage = new BodyMessage();
		bodymessage.getContent();
		message.setBody(bodymessage);
		return message;
	}
}
