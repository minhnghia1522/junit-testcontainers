package com.example.microsoftgraphoauth2.Model.Message;

import java.util.Scanner;

public class BodyMessage {
	private String content;
	private String contentType;

	public BodyMessage(String content) {
		this.content = content;
	}

	public BodyMessage() {
	}

	public String getContent() {
		if (this.content == null || this.content.isBlank()) {
			Scanner sc = new Scanner(System.in);
			System.out.print("Message: ");
			this.content = sc.nextLine();
		}
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
}
