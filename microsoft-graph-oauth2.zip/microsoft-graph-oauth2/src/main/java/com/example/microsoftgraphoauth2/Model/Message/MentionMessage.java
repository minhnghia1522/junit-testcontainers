package com.example.microsoftgraphoauth2.Model.Message;

import java.util.Scanner;

import com.example.microsoftgraphoauth2.Model.User;

public class MentionMessage {
	private String id;
	private String mentionText;
	private Mentioned mentioned;

	public String getId() {
		return "0";
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMentionText() {
		return mentionText;
	}

	public void setMentionText(String mentionText) {
		this.mentionText = mentionText;
	}

	public Mentioned getMentioned() {
		return mentioned;
	}

	public void setMentioned(Mentioned mentioned) {
		this.mentioned = mentioned;
	}

}
