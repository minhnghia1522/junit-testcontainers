package com.example.microsoftgraphoauth2.Model.Message;

import com.example.microsoftgraphoauth2.Model.User;

public class Mentioned {
	private User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}
