package com.example.microsoftgraphoauth2.Model.Message;

import java.util.List;

public class Message {
	private BodyMessage body;
	private List<MentionMessage> mentions;

	public BodyMessage getBody() {
		return body;
	}

	public void setBody(BodyMessage body) {
		this.body = body;
	}

	public List<MentionMessage> getMentions() {
		return mentions;
	}

	public void setMentions(List<MentionMessage> mentions) {
		this.mentions = mentions;
	}

}
