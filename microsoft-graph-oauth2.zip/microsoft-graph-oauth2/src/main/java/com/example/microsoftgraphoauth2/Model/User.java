package com.example.microsoftgraphoauth2.Model;

import java.util.Scanner;

public class User {
	private String id;
	private String displayName;
	private String userIdentityType;

	public String getId() {
		if (this.id == null || this.id.isBlank()) {
			Scanner sc = new Scanner(System.in);
			System.out.print("User ID: ");
			this.id = sc.nextLine();
		}
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDisplayName() {
		if (this.displayName == null || this.displayName.isBlank()) {
			Scanner sc = new Scanner(System.in);
			System.out.print("Display Name: ");
			this.displayName = sc.nextLine();
		}
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getUserIdentityType() {
		return userIdentityType;
	}

	public void setUserIdentityType(String userIdentityType) {
		this.userIdentityType = userIdentityType;
	}

}
