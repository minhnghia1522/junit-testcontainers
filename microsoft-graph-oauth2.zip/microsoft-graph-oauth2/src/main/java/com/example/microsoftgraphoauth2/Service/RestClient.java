package com.example.microsoftgraphoauth2.Service;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
public class RestClient<T> {
	private HttpEntity<T> request;
	private HttpEntity<MultiValueMap<String, String>> requestForm;
	private T bodyRequest;
	private MultiValueMap<String, String> bodyRequestForm;
	private HttpHeaders headers;

	public HttpEntity<T> getRequest() {
		this.request = new HttpEntity<T>(bodyRequest, headers);
		return request;
	}

	public HttpEntity<MultiValueMap<String, String>> getRequestForm() {
		this.requestForm = new HttpEntity<MultiValueMap<String, String>>(bodyRequestForm, headers);
		return requestForm;
	}

	public T getBodyRequest() {
		return bodyRequest;
	}

	public void setBodyRequest(T bodyRequest) {
		this.bodyRequest = bodyRequest;
	}

	public void setBodyRequest(MultiValueMap<String, String> bodyRequestForm) {
		this.bodyRequestForm = bodyRequestForm;
	}

	public HttpHeaders getHeaders() {
		return headers;
	}

	public HttpHeaders getNewHeaders() {
		this.headers = new HttpHeaders();
		return headers;
	}

	public RestClient<T> setHeaders(HttpHeaders headers) {
		this.headers = headers;
		return this;
	}
}
