package com.example.microsoftgraphoauth2.Util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ApplicationData {
	@Value("${ChatDemo.channelID}")
	private String channelID;
	@Value("${ChatDemo.teamID}")
	private String teamID;
	public String getChannelID() {
		return channelID;
	}
	public void setChannelID(String channelID) {
		this.channelID = channelID;
	}
	public String getTeamID() {
		return teamID;
	}
	public void setTeamID(String teamID) {
		this.teamID = teamID;
	}

	
}
