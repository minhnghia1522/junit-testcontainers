package com.example.microsoftgraphoauth2.Util;

public final class Contants {
	public static final String MICROSOFT_GRAPH_DOMAIN = "https://graph.microsoft.com/v1.0/";
	public static final String SIGN_IN_MICROSOFT_DOMAIN = "https://login.microsoftonline.com/";
	public static final String FECTH_TOKEN = "/oauth2/v2.0/token";

}
