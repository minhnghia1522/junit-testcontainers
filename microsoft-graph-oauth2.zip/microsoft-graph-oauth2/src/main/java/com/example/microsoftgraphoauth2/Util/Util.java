package com.example.microsoftgraphoauth2.Util;

import org.springframework.stereotype.Component;

@Component
public class Util {
	public Boolean isAccessTokenValid(String value) {
		if (value == null || value.isBlank()) {
			return false;
		}
		return true;
	}
}
